// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xmultivariate.h"

extern XMultivariate_Config XMultivariate_ConfigTable[];

XMultivariate_Config *XMultivariate_LookupConfig(u16 DeviceId) {
	XMultivariate_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMULTIVARIATE_NUM_INSTANCES; Index++) {
		if (XMultivariate_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMultivariate_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMultivariate_Initialize(XMultivariate *InstancePtr, u16 DeviceId) {
	XMultivariate_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMultivariate_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMultivariate_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

