// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xpnq.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XPnq_CfgInitialize(XPnq *InstancePtr, XPnq_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XPnq_Set_a(XPnq *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPnq_WriteReg(InstancePtr->Control_BaseAddress, XPNQ_CONTROL_ADDR_A_DATA, Data);
}

u32 XPnq_Get_a(XPnq *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPnq_ReadReg(InstancePtr->Control_BaseAddress, XPNQ_CONTROL_ADDR_A_DATA);
    return Data;
}

void XPnq_Set_b(XPnq *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPnq_WriteReg(InstancePtr->Control_BaseAddress, XPNQ_CONTROL_ADDR_B_DATA, Data);
}

u32 XPnq_Get_b(XPnq *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPnq_ReadReg(InstancePtr->Control_BaseAddress, XPNQ_CONTROL_ADDR_B_DATA);
    return Data;
}

u32 XPnq_Get_c(XPnq *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPnq_ReadReg(InstancePtr->Control_BaseAddress, XPNQ_CONTROL_ADDR_C_DATA);
    return Data;
}

u32 XPnq_Get_c_vld(XPnq *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPnq_ReadReg(InstancePtr->Control_BaseAddress, XPNQ_CONTROL_ADDR_C_CTRL);
    return Data & 0x1;
}

