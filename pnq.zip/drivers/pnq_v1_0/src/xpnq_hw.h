// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2.2 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of a
//        bit 15~0 - a[15:0] (Read/Write)
//        others   - reserved
// 0x14 : reserved
// 0x18 : Data signal of b
//        bit 15~0 - b[15:0] (Read/Write)
//        others   - reserved
// 0x1c : reserved
// 0x20 : Data signal of c
//        bit 31~0 - c[31:0] (Read)
// 0x24 : Control signal of c
//        bit 0  - c_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPNQ_CONTROL_ADDR_A_DATA 0x10
#define XPNQ_CONTROL_BITS_A_DATA 16
#define XPNQ_CONTROL_ADDR_B_DATA 0x18
#define XPNQ_CONTROL_BITS_B_DATA 16
#define XPNQ_CONTROL_ADDR_C_DATA 0x20
#define XPNQ_CONTROL_BITS_C_DATA 32
#define XPNQ_CONTROL_ADDR_C_CTRL 0x24

